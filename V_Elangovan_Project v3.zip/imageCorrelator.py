# Name: Vinodkumar Elangovan
# Email: vinod.elangovan@gmail.com
# Purpose: Project for 'Python for data analytics and scientific computing'

###################### PROJECT GOAL ###################### 
# The goal is to locate a known pattern in an image, using filtering and 
# correlation of the image content. This would illustrate a practical application 
# of FFT to perform convolution. The project could be used to search for one 
# pattern across multiple images, or to locate different patterns on one image. 
# The pattern and the image would both be in the form of .PNG files.
###################### PROJECT GOAL ###################### 
from classImage import (_Class_Image, padImages, get2DIndex, show_On_Plot, 
                        acceptableMatch)
import pylab as plb
from mpl_toolkits.mplot3d import Axes3D
import sys

# Set some default parameters
show3D = True
secondsToShowResult = 10
# Get any command line args to overwrite defaults
if len(sys.argv) > 1:
    if sys.argv[1] == 'hide3D':
        show3D = False
elif len(sys.argv) > 2:
    secondsToShowResult = int(sys.argv[2])

# First, get the file path to targets and 'images in which to search'
try:
    targetsFile = open(r'targets.txt', 'r')
    listOfTargetPaths = targetsFile.readlines()
    print(listOfTargetPaths)
    imagesToSearchFile = open(r'imagesToSearch.txt', 'r')
    listOfImagePaths = imagesToSearchFile.readlines()
    print(listOfImagePaths)
finally:
    targetsFile.close()
    imagesToSearchFile.close()

# Keep the left side of the figure to show images (target/image being searched)
plb.figure('Correlation of images', figsize=(16,9))
plb.subplot(1, 2, 1)

# Create list to store all specified targets, in the form of instances
listOfTargets = []

for tgtPath in listOfTargetPaths:
    
    # TARGET IMAGE (PATTERN TO LOOK FOR)
    target = _Class_Image(tgtPath.rstrip())
    tName = target.get_Image_Name()
    
    target.rgb_To_Gray()
    target.show_On_Plot(True, 'Target image (Grayscale) - {}'.format(tName), 1)
    
    target.rotate_Image_By_180()
    target.show_On_Plot(True, 'Target image (Flipped) - {}'.format(tName), 1)
    
    target.apply_Edge_Filter()
    # (OPTIONAL) second round of edge enhancement
    target.apply_Edge_Filter()
    target.show_On_Plot(True, 'Target image (Edge enhanced) - {}'.format(tName), 1)
    
    listOfTargets.append(target)

# Pick an IMAGE IN WHICH TO SEARCH FOR PATTERN(S)
for imgPath in listOfImagePaths:
    
    toSearchImage = _Class_Image(imgPath.rstrip())
    
    toSearchImage.rgb_To_Gray()
    siName = toSearchImage.get_Image_Name()
    
    foundBoxes = [] # keep track of found patterns, to annotate them at the end
    
    # Pick a PATTERN and search for it
    for tgtImage in listOfTargets:
        plb.clf()
        plb.subplot(1, 2, 1)
        
        tiName = tgtImage.get_Image_Name()
        
        # PAD THE IMAGES (both imageToSearch and targetImage)
        padImages(tgtImage, toSearchImage)
        
        toSearchImage.show_On_Plot(True, ('Image to search (Padded) - {}'
                            .format(siName)), 1, True)
        tgtImage.show_On_Plot(True, 'Target image (Padded) - {}'.format(tiName), 
                                1, True)
        
        # AFTER IMAGE PREPARATION, CROSS CORRELATE 
        result = toSearchImage.correlate_With_Target(tgtImage)
        
        # SHOW THE RESULT OF CORRELATING the two images
        rowFound, colFound = get2DIndex(result.argmax(), result.shape[1])
        print('The highest intensity value is at ', rowFound, colFound)
        show_On_Plot(result, True, ('Correlation result - {} in {}'
                                .format(tiName, siName)), 1)
        
        # Flatten the result 2D array, and PLOT THE HISTOGRAM to show 
        # distribution of intensities
        # Keep the right side of the plot to show histogram/analysis
        plb.subplot(1, 2, 2)
        binCount = 20
        histLabel = 'Bin count: {}, Bin width: {}'.format(binCount, 1.0/binCount)
        histOfResult = plb.hist(result.flatten(), bins=binCount, label=histLabel)
        # Check to see if the distribution indicates a 'bright spot' in result
        isAMatch, sdAbove, percentOfHighIntensity = acceptableMatch(result, histOfResult)
        criteria = """Diff from Mean in SDs: {:6.2f}, Percent of high intensity
                pixels: {:9.6f}""".format(sdAbove, percentOfHighIntensity)
        plb.title("Distribution of correlation intensity \n" + criteria)
        plb.legend(loc='upper right')
        plb.xlabel("Intensity"), plb.ylabel("Pixel count")
        plb.grid()
        plb.pause(secondsToShowResult)
        
        # Show the resulting image AS A 3D SURFACE PLOT (across entire figure)
        if show3D:
            plb.clf()
            ax = Axes3D(plb.figure('Correlation of images'))
            # #ax = fig.gca(projection='3d')
            
            # Create x and y coordinate arrays
            xx, yy = plb.mgrid[0:result.shape[0], 0:result.shape[1]]
            ax.plot_surface(xx, yy, result, rstride=4, cstride=4, cmap=plb.cm.autumn)
                    # takes ~5 mins to render initial plot (at full sampling)
            ax.view_init(30, 55) # set initial viewing angle for 3D surface plot
            plb.title('Correlation result - {} in {}'.format(tiName, siName))
            ax.w_xaxis.set_pane_color((0.2, 0.2, 0.2, 1.0)) # set to a darker 
            ax.w_yaxis.set_pane_color((0.2, 0.2, 0.2, 1.0)) # background to better
            ax.w_zaxis.set_pane_color((0.2, 0.2, 0.2, 1.0)) # see any spikes
            plb.pause(secondsToShowResult)
        
        # Now, make note of the LOCATION ON THE IMAGE WHERE THE PATTERN WAS FOUND, 
        # so as to draw a boundary (same size as target image) from the found site,
        # extending to the left and above
        if isAMatch:
            tgtRows, tgtCols = tgtImage.imgData.shape[0], tgtImage.imgData.shape[1]
            #toSearchImage.mark_With_Border(rowFound, colFound, tgtRows, tgtCols)
            foundBoxes.append((tiName, rowFound, colFound, tgtRows, tgtCols))
    
    plb.clf()
    plb.subplot(1, 1, 1)
    toSearchImage.show_On_Plot(True, ('Image to search (with any targets found highlighted) - {}'
                                .format(siName)), 10, False, foundBoxes)
    
plb.show()
plb.close()