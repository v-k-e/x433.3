import matplotlib.image as img
import pylab as plb
from scipy.fftpack import fft2, ifft2
import os
import matplotlib.patches as patches

class _Class_Image:
    
    def __init__(self, filePath):
        self.filePath = filePath
        self.imgData = img.imread(filePath)
        #row, col = self.imgData.shape[0], self.imgData.shape[1]
        #self.imgEdge = plb.zeros((row,col))
        
    def rgb_To_Gray(self):
        if (len(self.imgData.shape) == 3) and (self.imgData.shape[2] >= 3):
            r, g, b = self.imgData[:,:,0], self.imgData[:,:,1], self.imgData[:,:,2]
            gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
        
            self.imgData = gray
    
    def rotate_Image_By_180(self):
        grayImg = self.imgData
        row, col = grayImg.shape[0], grayImg.shape[1]
        lToRImg = plb.zeros((row,col))
        rotImg = plb.zeros((row,col))

        j = 0
        while j<col:
            lToRImg[:,j] = grayImg[:,col-1-j]
            j += 1
        i = 0
        while i<row:
            rotImg[i,:] = lToRImg[row-1-i,:]
            i += 1
        
        self.imgData = rotImg
        
    def apply_Edge_Filter(self):
        edgeFilter = plb.matrix([ [-1/8, -1/8, -1/8], 
                                  [-1/8,    1, -1/8], 
                                  [-1/8, -1/8, -1/8] ])
        #k = 2
        #edgeFilter = plb.matrix([ [-k/8, -k/8, -k/8], [-k/8, k+1, -k/8], 
        #                           [-k/8, -k/8, -k/8] ])
        grayImg = self.imgData
        row, col = grayImg.shape[0], grayImg.shape[1]
        paddedImg = plb.zeros((row+2, col+2))
        # copy source into [1:row,1:col] of paddedImg
        paddedImg[1:row+1, 1:col+1] = grayImg 
        
        edgeImg = plb.zeros((row,col))
        
        i, j = 1, 1
        while i<=row:
            while j<=col:
                
                #enhPointMtx = paddedImg[i-1:i+2,j-1:j+2] * edgeFilter
                enhPointMtx = plb.multiply(paddedImg[i-1:i+2,j-1:j+2], edgeFilter)
                #if enhPointMtx.sum() > 0.:
                edgeImg[i-1,j-1] = enhPointMtx.sum()
                
                j += 1
            i += 1
            j = 1
        
        self.imgData = edgeImg
           
    def show_On_Plot(self, gray=True, title='', duration=600, padded=False, drawBoxes=[]):
        if padded:
            dataToPlot = self.paddedImgData
        else:
            dataToPlot = self.imgData
        show_On_Plot(dataToPlot, gray, title, duration, drawBoxes)            
        
        
    def pad_To_Size(self, size):
        rows, cols = self.imgData.shape[0], self.imgData.shape[1]
        self.paddedImgData = plb.zeros((size, size))
        self.paddedImgData[0:rows, 0:cols] = self.imgData
        
    def correlate_With_Target(self, anImage):
        """Correlate the 2 images by finding FFT and then convolution (by 
           multiplying)
           NOTE the use of fft2/ifft2 for performing FFT of 2D data
        """
        tgtImgFD = fft2(anImage.paddedImgData)
        intImgFD = fft2(self.paddedImgData)

        convImgFD = plb.multiply(tgtImgFD, intImgFD)

        convImg = ifft2(convImgFD)

        # Normalize the correlation result to be in the [0.0:1.0] range
        minVal = convImg.real.min()
        maxVal = convImg.real.max()
        normCorrResult = (convImg.real - minVal) / (maxVal-minVal)
        
        return normCorrResult
    
    def mark_With_Border(self, rFound, cFound, tgtRows, tgtCols):
        self.imgData[rFound, (cFound-tgtCols+1):(cFound+1)] = 0.0              # bottom
        self.imgData[(rFound-tgtRows+1), (cFound-tgtCols+1):(cFound+1)] = 0.0  # top
        self.imgData[(rFound-tgtRows+1):(rFound+1), cFound] = 0.0              # right
        self.imgData[(rFound-tgtRows+1):(rFound+1), (cFound-tgtCols+1)] = 0.0  # left

    def get_Image_Name(self):
        fileName = os.path.basename(self.filePath)
        return os.path.splitext(fileName)[0]


def show_On_Plot(data, gray=True, title='', duration=600, drawBoxes=[]):
    if gray:
        plb.imshow(data, cmap=plb.get_cmap('gray'))
    else:
        plb.imshow(data)
    plb.title(title)
    
    # See if there are drawBoxes - a list of tuples of the form 
    # (tiName, rowFound, colFound, tgtRows, tgtCols) - that indicate whether to 
    # annotate on top of the image being displayed
    if drawBoxes:
        for box in drawBoxes:
            ax = plb.gca()
            #plb.text(box[2], box[1], box[0])
            plb.annotate(box[0], xy=(box[2],box[1]), xytext=(box[2]+10,box[1]+10),
                         arrowprops=dict(arrowstyle='->'))
            # Create a Rectangle patch
            rect = patches.Rectangle((box[2]-box[4], box[1]-box[3]), 
                                box[4], box[3], edgeColor='r', facecolor='none')
            # Add the patch to the Axes
            ax.add_patch(rect)
    
    plb.pause(duration)

def get2DIndex(flatIndex, aRowWidth):
    """Determine, based on flattened index, the (row, col) in Python convention,
       that is, starting at 0
    """
    row = flatIndex//aRowWidth
    col = flatIndex - (row*aRowWidth)
    return row, col

def acceptableMatch(correlationResult, histOfResult):
    """Given the 2D result of correlating the target image and the search image, 
       and also the histogram, determine if it counts as an acceptable match, 
       using these criteria;
            a. Max intensity is more than 4xSD above the mean
            b. Ratio of pixels with high intensity is below 0.01
    """
    
    meanOfResult = plb.mean(correlationResult)
    sdOfResult = plb.std(correlationResult)
    maxIntensity = correlationResult.max()
    
    diffFromMeanInSDs = (maxIntensity - meanOfResult) / sdOfResult
    
    binCount = len(histOfResult[0])
    lastQuarterStart = int(3 / 4 * binCount)
    pixelsWithHighIntensity = histOfResult[0][lastQuarterStart:binCount].sum()
    totalPixels = histOfResult[0][:].sum()
    pixelsWithHighIntensityPercent = (pixelsWithHighIntensity / totalPixels)*100.0
    
    isAMatch = (diffFromMeanInSDs > 4.0) and (pixelsWithHighIntensityPercent < 1.0)
    
    return isAMatch, diffFromMeanInSDs, pixelsWithHighIntensityPercent

def padImages(imageA, imageB):
    """Given two images, find the largest side, and the power of 2 above
        Then, pad both supplied images to that size
    """
    
    aRows, aCols = imageA.imgData.shape[0], imageA.imgData.shape[1]
    bRows, bCols = imageB.imgData.shape[0], imageB.imgData.shape[1]
    largestSide = max(aRows, aCols, bRows, bCols)
    paddedSide = 2
    while paddedSide < largestSide:
        paddedSide *= 2
    
    imageA.pad_To_Size(paddedSide)
    imageB.pad_To_Size(paddedSide)
    
    return paddedSide
