EXAMPLE INVOCATION from command line, with current directory containing all zipped files;

"D:\python\proj\V_Elangovan_Project>python imageCorrelator.py"
(by DEFAULT, displays 3D surface plots, so complete run took about 3-4 minutes for given input)

"D:\python\proj\V_Elangovan_Project>python imageCorrelator.py hide3D"
(this option skips display of 3D surface plot, thereby SHORTENING the runtime)

"D:\python\proj\V_Elangovan_Project>python imageCorrelator.py hide3D 30"
(this option increases result display duration to 30 seconds, from default of 10 seconds)

------- PLATFORM ON WHICH RUN -------

Windows 7 (64-bit)
Python v3.6.5
Using Pyzo and Ipython

------- DEPENDENCIES -------

a. imageCorrelator.py is the script to run
b. imageCorrelator.py depends on classImage.py (residing in same directory)
c. imageCorrelator.py gets its input (list of targets and images to search)
   from target.txt/imagesToSearch.txt (residing in same directory)
d. target.txt/imagesToSearch.txt currently reference some .PNG files, residing inside 
  'TestData' folder
e. Other libraries used are {os, sys, pylab, scipy, matplotlib, mpl_toolkits.mplot3d}

------- HOW TO RUN -------

a. To execute the script (imageCorrelator.py) from Pyzo, I had to set the 'current 
   directory' to the folder containing imageCorrelator.py
b. To execute the script from command line (Windows), I changed the 'current directory' 
   to its folder and invoked 'python imageCorrelator.py'

Once invoked, the program first displays each target image (patterns that it will try
to find), and then for each 'image in which to search', it will try to find one pattern 
at a time, and show the location for each pattern it could successfully locate on the image.

The program has pauses between different displays, and proceeds by itself.

The program takes a pause (30 secs) while trying to render the '3D Surface Plot' of correlation result.